import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Player player = new Player();
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите первую строку");
        String str = scn.nextLine();
        str = str.replaceFirst("пошёл","пицца");
        System.out.println(str.replace("пошёл",""));
        Scanner scn2 = new Scanner(System.in);
        System.out.println("Введите вторую строку");
        String str2 = scn2.nextLine();
        str2 = str2.replaceFirst("судьбы","пицца" );
        System.out.println(str2.replace("судьбы",""));







    }
}
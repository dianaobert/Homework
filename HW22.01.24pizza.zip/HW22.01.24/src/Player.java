public class Player {
    String string;



}

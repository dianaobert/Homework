public class Main {
    public static void main(String[] args) {
        char c = 'G';
        int i = 89;
        byte b = 4;
        short s = 64;
        float f = 4.7333436f;
        double d = 4.355453532;
        long l = 12121;
        System.out.println(c);
        System.out.println(i);
        System.out.println(b);
        System.out.println(s);
        System.out.println(f);
        System.out.println(d);
        System.out.println(l);
        //Дано трехзначное число. Вывести на экран все цифры этого числа
        //Пример: 345
        //Вывод в консоль: Число 345 -> 3, 4, 5
        //Другой пример: 987
        //Вывод в консоль: Число 987 -> 9, 8, 7
        int a = 345;
        int e = a/10;
        System.out.println(a/100);
        System.out.println(e%10);
        System.out.println(a%10);

    }
}
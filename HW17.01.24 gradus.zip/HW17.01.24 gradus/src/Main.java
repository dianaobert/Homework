import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Здравствуйте, я программа Градус, я могу переводить температуру из шкалы цельсия в шкалу фарегейт. А как вас зовут?");
        String name = scn.nextLine();
        System.out.println("очень приятно. Введите пожалуйста сколько градусов цельсия ");
        int gradCelsius = scn.nextInt();
        int gradfar = gradCelsius*9/5+32;
        System.out.println("спасибо. Температура " + gradCelsius + " по цельсию соответствует " + gradfar + " градусам по шкале фаренгейт");





    }
}
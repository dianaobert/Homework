import java.util.Scanner;

public class Numbers2 {
    //Создать программу, выводящую на экран ближайшее к 10 из двух чисел,
    // записанных в переменные m и n.
    //Числа могут быть, как целочисленные, так и дробные.
    public static void main(String[] args) {
        System.out.println("введите два числа");
    Scanner scn = new Scanner(System.in);
  int m = scn.nextInt();
    int n = scn.nextInt();
    int res1 = m - 10;
    int res2 = n - 10;

    if (Math.abs(res1) > (Math.abs(res2))) {
        System.out.println(n);}
    else {
        System.out.println(m);


        }





    }
}
import java.util.Random;
import java.util.Scanner;

public class Numbers {
    public static void main(String[] args) {
        //Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
        // Программа генерирует два целых однозначных числа. Программа задаёт вопрос:
        // результат умножения первого числа на второе?
        // Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
        // Если пользователь ответил неправильно, то программа должна показать правильный ответ.
        Random rnd = new Random();
        int number1 = rnd.nextInt(1,10);
        int number2 = rnd.nextInt(1,10);
        System.out.println("Задание: найдите произведение двух чисел");
        System.out.println(" первое число " + number1);
        System.out.println(" второе число " + number2);
        System.out.println(" введите результат ");
        Scanner scn = new Scanner(System.in);
        int yourNumber = scn.nextInt();
        int res = number1*number2;
        if (yourNumber==res){
            System.out.println("верно!");
        }else{
            System.out.println("неверно...правильный ответ " +res);
        }
    }
    }
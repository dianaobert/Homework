import java.util.Scanner;

public class Elvis {
    public static void main(String[] args) {
        System.out.println("введите год");
        Scanner scn = new Scanner(System.in);
        int year = scn.nextInt();
        String status = year < 1935 ? "Элвис ещё не родился" : (year > 1977 ? "Элвис навсегда в наших сердцах!" : "Элвис жив!");
        System.out.println(status);
    }
    }
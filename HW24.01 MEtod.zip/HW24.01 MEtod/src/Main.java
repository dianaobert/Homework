import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scn = new Scanner(System.in);
        System.out.println("Введите первое число");
        double dNumber1 = scn.nextDouble();
        System.out.println("Введите второе число");
        double dNumber2 = scn.nextDouble();

        double resultSum = summe(dNumber1, dNumber2);
        double resultMult = multiply(dNumber1, dNumber2);
        double reultSub = subtraction(dNumber1, dNumber2);
        double resultDiv = division(dNumber1, dNumber2);
        double resultDiv2 = division2(dNumber1, dNumber2);
        double resultSquared1= squared1(dNumber1);
        double resultSquared2= squared2(dNumber2);

        System.out.println("Сумма равна: " + resultSum);
        System.out.println("произведение равно: " + resultMult);
        System.out.println("разность равна: " + reultSub);
        System.out.println("результат деления равен: " + resultDiv);
        System.out.println("результат деления по модулю равен: " + resultDiv2);
        System.out.println("квадрат первого числа равен: " + resultSquared1);
        System.out.println("квадрат второго числа равен: " + resultSquared2);



    }
    public static double summe (double number1, double number2) {
        double resultOfSumme = number1 + number2;
        return resultOfSumme;
    }

public static double multiply (double number1, double number2) {
        double resultOfMultiply = number1 * number2;
        return resultOfMultiply;
    }
public static double subtraction (double number1, double number2) {
        double resultOfSubtraction = number1 - number2;
        return resultOfSubtraction;

}
public static double division (double number1, double number2) {
        double resultOfDivision = number1/number2;
        return resultOfDivision;

}
public static double division2 (double number1, double number2) {
        double resultOfDivision2 = number1%number2;
        return resultOfDivision2;

}
public static double squared1 (double number1) {
        double resultOfSqrd1 = number1*number1;
        return resultOfSqrd1;

}
public static double squared2 (double number2){
    double resultOfSqrd2 = number2*number2;
    return resultOfSqrd2;

}
}